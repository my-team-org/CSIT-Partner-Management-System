from django.apps import AppConfig


class DetailConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "detail"
