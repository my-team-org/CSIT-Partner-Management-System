from django.contrib import admin
from main.models import *

# Register your models here.
admin.site.register(JobPosition)
admin.site.register(Jobbenefit)
admin.site.register(Job)
admin.site.register(Company)
admin.site.register(Company_image)
admin.site.register(HumanResouce)
admin.site.register(HumnanResource_Job)
admin.site.register(Student)
admin.site.register(Student_job)
admin.site.register(application_forms)
admin.site.register(Review)